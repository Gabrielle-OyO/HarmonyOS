[toc]

# 1. 准备工作与说明

## 1.1 准备工作

请先下载以下文件，里面有文档：

https://gitee.com/weidongshan/openharmony_for_imx6ull/repository/archive/master.zip

参考GIT中的文档，安装好虚拟机，从GIT中下载Liteos-a源码，打上IMX6ULL的补丁。

## 1.2 说明

正在努力移植中，最终文档也会上传到上述GIT里。

本文档可以使用Typora打开。

# 2. Makefile编译系统分析

## 2.1 从最终的链接命令看Liteos-a的组成

* 链接命令如下

  liteos-a由一系列的库文件组成，reset_vector是它的入口。

![link_liteos-a](pic\liteos-a_link.png)
* 查看链接脚本

  ![liteos_llvm.ld](pic\liteos_llvm.ld.png)

* 查看liteos.map文件

  ![liteos.map](pic\liteos_map.png)

## 2.2 Makfile中常用变量

1. LITEOSTOPDIR                        // kernel/liteos_a
2. LITEOSTHIRDPARTY               // third_party
3. LITEOS_MK_PATH                   // kernel/liteos_a/tools/build/mk
4. MK_PATH  = $(LITEOSTOPDIR)/tools/build/mk       // kernel/liteos_a/tools/build/mk

## 2.3 包含的文件
Makefile
	-include $(LITEOSTOPDIR)/tools/build/config.mk
		-include $(LITEOSTOPDIR)/tools/build/mk/los_config.mk
			-include $(LITEOSTOPDIR)/.config
			include $(LITEOSTOPDIR)/arch/cpu.mk
				-include $(LITEOSTOPDIR)/arch/arm/arm.mk
			include $(LITEOSTOPDIR)/platform/bsp.mk
			include $(LITEOSTOPDIR)/../../vendor/nxp/imx6ull/imx6ull.mk
			include $(LITEOSTOPDIR)/../../drivers/hdf/lite/hdf_lite.mk
				include $(LITEOSTOPDIR)/../../vendor/nxp/hdf/hdf_vendor.mk
			-include $(LITEOSTOPDIR)/3rdParty/3rdParty.mk
		-include $(LITEOS_MK_PATH)/liteos_tables_ldflags.mk
	-include $(LITEOS_MK_PATH)/dynload.mk

## 2.4 把Makefile全部展开
得到了一个Makefile_all.txt，
分析Makefile_all.txt，就可以知道编译过程。

## 2.5 分析在kernel/liteos_a下执行make的过程
### 2.5.1 第1个目标
all: $(OUT) $(BUILD) $(LITEOS_TARGET) $(APPS)

### 2.5.2 目标：OUT
* OUT目标：

  创建了目录：kernel/liteos_a/imx6ull/lib

  把board.ld.S编译成了board.ld，这是链接文件。
```
# .config文件中， LOSCFG_PLATFORM="imx6ull"
OUT  = $(LITEOSTOPDIR)/out/$(LITEOS_PLATFORM)

$(OUT): $(LITEOS_MENUCONFIG_H)
	$(HIDE)mkdir -p $(OUT)/lib
	$(HIDE)$(CC) -I$(LITEOS_PLATFORM_BASE)/include -I$(BOARD_INCLUDE_DIR) \
		-E $(LITEOS_PLATFORM_BASE)/board.ld.S \
		-o $(LITEOS_PLATFORM_BASE)/board.ld -P
```
* OUT的依赖：LITEOS_MENUCONFIG_H

  配置内核，生成头文件autoconf.h。
```
LITEOS_MENUCONFIG_H = $(LITEOSTOPDIR)/include/generated/autoconf.h

KCONFIG_FILE_PATH = $(LITEOSTOPDIR)/Kconfig

$(LITEOS_MENUCONFIG_H):
ifneq ($(LITEOS_PLATFORM_MENUCONFIG_H), $(wildcard $(LITEOS_PLATFORM_MENUCONFIG_H)))
	$(HIDE)$(MAKE) genconfig
endif

genconfig:$(MENUCONFIG_PATH)/conf
	$(HIDE)mkdir -p include/config include/generated
	$< --silentoldconfig $(KCONFIG_FILE_PATH)
	-mv -f $(LITEOS_MENUCONFIG_H) $(LITEOS_PLATFORM_MENUCONFIG_H)
```
### 2.5.3 目标：BUILD
创建目录 kernel/liteos_a/imx6ull/obj

```
OUT  = $(LITEOSTOPDIR)/out/$(LITEOS_PLATFORM)
BUILD  = $(OUT)/obj
$(BUILD):
	$(HIDE)mkdir -p $(BUILD)
```

### 2.5.4 目标：LITEOS_TARGET

这是核心，进入子目录执行make，把子目录中的文件链接为一个库。

最后，把这些库链接为liteos内核。

```
LITEOS_TARGET = liteos
$(LITEOS_TARGET): $(__LIBS)
	$(HIDE)touch $(LOSCFG_ENTRY_SRC)

	$(HIDE)for dir in $(LITEOS_SUBDIRS); \
	do $(MAKE) -C $$dir all || exit 1; \
	done

	$(LD) $(LITEOS_LDFLAGS) $(LITEOS_TABLES_LDFLAGS) $(LITEOS_DYNLDFLAGS) -Map=$(OUT)/$@.map -o $(OUT)/$@ --start-group $(LITEOS_LIBDEP) --end-group
#	$(SIZE) -t --common $(OUT)/lib/*.a >$(OUT)/$@.objsize
	$(OBJCOPY) -O binary $(OUT)/$@ $(LITEOS_TARGET_DIR)/$@.bin
	$(OBJDUMP) -t $(OUT)/$@ |sort >$(OUT)/$@.sym.sorted
	$(OBJDUMP) -d $(OUT)/$@ >$(OUT)/$@.asm
#	$(NM) -S --size-sort $(OUT)/$@ >$(OUT)/$@.size
```
* 目标：__LIBS

  ```
  # 没做什么事
  __LIBS = libs
  $(__LIBS): $(OUT) $(CXX_INCLUDE)
  ```

  

* 命令：$(HIDE)touch $(LOSCFG_ENTRY_SRC)

  每次都要编译los_config.c，touch一下

  ```
  LOSCFG_ENTRY_SRC    = $(LITEOSTOPDIR)/kernel/common/los_config.c
  ```

* 命令：进入每个LITEOS_SUBDIRS，执行make，后面重点讲解各个子目录的编译

  ```
  # LIB_SUBDIRS 等于一系列的目录
  LIB_SUBDIRS :=
  LIB_SUBDIRS             += arch/arm/$(LITEOS_ARCH_ARM)  # 就是arch/arm/arm
  LIB_SUBDIRS             += $(PLATFORM_BSP_HISI_BASE)
  LIB_SUBDIRS     += $(LITEOSTOPDIR)/kernel/common
  LIB_SUBDIRS       += kernel/base
  LIB_SUBDIRS     += $(IMX6ULL_BASE_DIR)/board
  LIB_SUBDIRS     += $(IMX6ULL_BASE_DIR)/driver/mtd/common
  LIB_SUBDIRS     += $(IMX6ULL_BASE_DIR)/driver/mtd/spi_nor
  LIB_SUBDIRS             += $(IMX6ULL_BASE_DIR)/driver/imx6ull-fb
  LIB_SUBDIRS             += $(IMX6ULL_BASE_DIR)/driver/imx6ull-uart
  LIB_SUBDIRS         += kernel/extended/cpup
  LIB_SUBDIRS        += lib/libc
  LIB_SUBDIRS        += lib/libsec
  LIB_SUBDIRS         += lib/libscrew
  LIB_SUBDIRS     += fs/fat
  LIB_SUBDIRS     += fs/jffs2
  
  LITEOS_SUBDIRS   = $(LIB_SUBDIRS)
  
  $(HIDE)for dir in $(LITEOS_SUBDIRS); \
  	do $(MAKE) -C $$dir all || exit 1; \
  	done
  ```
* 链接及各类处理
```
	$(LD) $(LITEOS_LDFLAGS) $(LITEOS_TABLES_LDFLAGS) $(LITEOS_DYNLDFLAGS) -Map=$(OUT)/$@.map -o $(OUT)/$@ --start-group $(LITEOS_LIBDEP) --end-group
#	$(SIZE) -t --common $(OUT)/lib/*.a >$(OUT)/$@.objsize
	$(OBJCOPY) -O binary $(OUT)/$@ $(LITEOS_TARGET_DIR)/$@.bin
	$(OBJDUMP) -t $(OUT)/$@ |sort >$(OUT)/$@.sym.sorted
	$(OBJDUMP) -d $(OUT)/$@ >$(OUT)/$@.asm
#	$(NM) -S --size-sort $(OUT)/$@ >$(OUT)/$@.size
```

### 2.5.5 怎么编译各个子目录

以kernel/liteos_a/fs/fat/Makefile为例：

![kernel/liteos_a/fs/fat/Makefile](pic\fat_makefile.png)

* 第1行包含config.mk
  
   这是包含一些预先定义的变量，比如默认的编译选项等。
   
* 定义了LOCAL_SRCS
  
   等于一系列C文件，这就是要编译的源文件。
   
* 定义了LOCAL_INCLUDE

   这是头文件的目录
   
* 定义了LOCAL_FLAGS

   这是编译选项

* 定义了MODULE_NAME
  
  一般等于当前目录的名字，比如fat，以后就编译得到libfat.a
  
* 怎么编译？看最后一行

   ```
   include $(MODULE)
   ```

   MODULE就是：

   ```
   MODULE = $(MK_PATH)/module.mk  # kernel/liteos_a/tools/build/mk/module.mk
   ```

   分析module.mk：

   ```
   # 找到第1个目标
   all : $(LIB)
   
   # LIB是什么, 如果没定义LOCAL_SO，LIB就是 lib$(MODULE_NAME).a, 比如 libfat.a
   ifeq ($(LOCAL_SO), y)
   LIBSO := $(OUT)/lib/lib$(MODULE_NAME).so
   LIBA := $(OUT)/lib/lib$(MODULE_NAME).a
   else
   LIBSO :=
   LIBA := $(OUT)/lib/lib$(MODULE_NAME).a
   endif
   LIB := $(LIBA) $(LIBSO)
   
   # 怎么编译 LIBA ? 看下图
   ```


![module](pic\module.png)



# 3. 添加STM32MP157单板

* 技巧1：

​       STM32MP157跟HI3516DV300都属于cortex A7 smp架构，可以搜索HI3516DV300并仿照它添加文件。

​		可以搜索“PLATFORM_HI3516DV300”，仿照它添加“PLATFORM_STM32MP157”。

​		只涉及2个文件：kernel/liteos_a/Kconfig、kernel/liteos_a/platform/Kconfig。

* 技巧2：

  海思芯片对应的源码在Liteos-a中并不开源，所以还需要参考IMX6ULL的代码。

## 3.1 在配置菜单Kconfig中添加STM32MP157

* 修改：kernel/liteos_a/Kconfig

![add_stm32mp157_kconfig](pic\add_stm32mp157_kconfig.png)

* 修改 kernel/liteos_a/platform/Kconfig

![add_stm32mp157_platform_kconfig](pic\add_stm32mp157_platform_kconfig.png)

## 3.2 添加STM32MP157的默认配置文件

* 配置文件
	位于 kernel/liteos_a/tools/build/config/debug。
	
	名字里含有clang的配置文件，是使用clang工具链；
	
	名字里不含有clang的配置文件，是使用GNU工具链。
	
	Liteos-a默认使用clang工具链。

![default_config_file](pic\default_config_file.png)

* 添加STM32MP157的配置文件
	仿照hi3516dv300_clang.config和imx6ull_clang.config添加。
```
cp  imx6ull_clang.config  stm32mp157_clang.config
```

​		再作如下修改：

![stm32mp157_clang.config](pic\stm32mp157_clang.config.png)



## 3.3 添加单板相关的代码

* 参考IMX6ULL来添加

  IMX6ULL单板相关的文件位于这个目录：vendor/nxp，内容如下：

  ```
  vendor
  └── nxp
      ├── hdf
      │   └── hdf_vendor.mk
      └── imx6ull
          ├── board
          │   ├── board.c
          │   ├── bsd_board.c
          │   ├── include
          │   │   ├── asm
          │   │   │   ├── hal_platform_ints.h
          │   │   │   └── platform.h
          │   │   ├── board.h
          │   │   ├── clock.h
          │   │   ├── platform_config.h
          │   │   ├── reset_shell.h
          │   │   ├── spinor.h
          │   │   └── uart.h
          │   └── Makefile
          ├── config
          │   ├── device_info
          │   │   └── device_info.hcs
          │   ├── hdf.hcs
          │   ├── i2c
          │   │   └── i2c_config.hcs
          │   └── Makefile
          ├── driver
          │   ├── hello
          │   │   ├── hello_drv.c
          │   │   └── Makefile
          │   ├── imx6ull-fb
          │   │   ├── imx6ull_lcd.c
          │   │   ├── imx6ull_lcdc.c
          │   │   ├── imx6ull_lcdc.h
          │   │   ├── imx6ull_lcd.h
          │   │   └── Makefile
          │   ├── imx6ull-i2c
          │   │   ├── i2c_dev.c
          │   │   ├── i2c_dev.h
          │   │   ├── i2c_imx6ull.c
          │   │   └── Makefile
          │   ├── imx6ull-uart
          │   │   ├── imx6ull_uart.h
          │   │   ├── Makefile
          │   │   ├── uart_core.c
          │   │   ├── uart_dev.c
          │   │   ├── uart_dev.h
          │   │   └── uart_imx6ull.c
          │   ├── mtd
          │   │   ├── common
          │   │   │   ├── BUILD.gn
          │   │   │   ├── include
          │   │   │   │   ├── hifmc_common.h
          │   │   │   │   ├── mtd_common.h
          │   │   │   │   └── spi_common.h
          │   │   │   ├── Makefile
          │   │   │   └── src
          │   │   │       ├── common.c
          │   │   │       ├── mtdblock.c
          │   │   │       ├── mtdchar.c
          │   │   │       └── mtd_list.c
          │   │   └── spi_nor
          │   │       ├── BUILD.gn
          │   │       ├── include
          │   │       │   └── spinor.h
          │   │       ├── Kconfig
          │   │       ├── Makefile
          │   │       └── src
          │   │           └── common
          │   │               ├── host_common.h
          │   │               ├── ramdisk.c.bak2
          │   │               ├── ramdisk.c.ok
          │   │               ├── spinor.c
          │   │               └── spinor_common.h
          │   └── touch
          │       ├── Makefile
          │       ├── touch_gt9xx.c
          │       └── touch_gt9xx.h
          └── imx6ull.mk
  ```

* 复制修改单板文件

  注意，这样添加的代码肯定无法用在STM32MP157上，以后还需要改代码。
  
  先复制再改名，如下图操作：

![add_stm32mp157_board_file](pic\add_stm32mp157_board_file.png)

* 修改Makefile

    在vendor/st目录下，执行以下命令：

  ```
  grep "imx6ull" * -nr | grep Makefile
  ```

  找到几个Makefile，把里面的”imx6ull“全部改名为"stm32mp157"，如下图：

![change_makefile_of_vendor_st](pic\change_makefile_of_vendor_st.png)



## 3.4 修改Makefile

我们提供了vendor/st目录，也修改了目录里面的Makefile，但是还需要修改其他Makefile，才会去编译这目录。

执行以下搜索命令：
```
grep "LOSCFG_PLATFORM_HI3516DV300" * -nwr
```

在得到的文件中，添加STM32MP157的项目，只涉及3个文件：

![modify_makefile_to_build_stm32mp157](pic\modify_makefile_to_build_stm32mp157.png)

### 3.4.1 修改kernel/liteos_a/Makefile

在顶层Makefile中，确定STM32MP157的文件系统类型，指定STM32MP157的单板源码路径。

![modify_kernel_liteos_a_Makefile](pic\modify_kernel_liteos_a_Makefile.png)

### 3.4.2 修改kernel/liteos_a/platform/Makefile

修改它，在使用STM32MP157是，也要编译kernel/common下的文件，这些是通用的文件。

![modify_kernel_liteos_a_platform_Makefile](pic\modify_kernel_liteos_a_platform_Makefile.png)

### 3.4.3 修改kernel/liteos_a/platform/bsp.mk

这涉及的是定时器的代码，单板相关的头文件目录。

![modify_kernel_liteos_a_platform_bsp.mk](pic\modify_kernel_liteos_a_platform_bsp.mk.png)

## 3.5 配置内核/编译/必定出错

肯定是会出错的，我们要做到是：根据启动流程、根据出错信息，反复修改并测试。

```
cd kernel/liteos_a
make clean
cp tools/build/config/debug/stm32mp157_clang.config .config
make  // 会提示你，让你选择很多配置项, ctrl + c退出
make menuconfig  // 马上退出，选择保存
cp  .config  tools/build/config/debug/stm32mp157_clang.config  // 配置文件就完整了
make  // 必定出错
```

* 题外话

  配置文件中，比如你配置了LOSCFG_PLATFORM_STM32MP157，

  但是不需要配置 LOSCFG_PLATFORM_HI3516DV300，

  在.config中，LOSCFG_PLATFORM_HI3516DV300也要写出来(写为"not set")，如下：

  ```
  LOSCFG_PLATFORM="stm32mp157"
  # LOSCFG_PLATFORM_HI3518EV300 is not set
  LOSCFG_PLATFORM_STM32MP157=y
  # LOSCFG_PLATFORM_HI3516DV300 is not set
  ```

  如果不写的话，make时就会提示：

  ```
  *
  * Restart config...
  *
  *
  * Platform
  *
  Board
    1. hi3516dv300 (PLATFORM_HI3516DV300) (NEW)
    3. hi3518ev300 (PLATFORM_HI3518EV300)
  > 3. stm32mp157 (PLATFORM_STM32MP157)
    4. imx6ull (PLATFORM_IMX6ULL)
  choice[1-4?]:
  ```

  所以，我们第一次配置时，干脆执行"make menuconfig"并立刻退出并保存，

  这会帮助我们在.config中把没用到的配置项也作为"# LOSCFG_XXX is not set"列出来。

  为防止下次配置时，仍然碰到这个问题，执行：

  ```
  cp  .config  tools/build/config/debug/stm32mp157_clang.config
  ```

  

# 4. 编译/出错/修改/测试

最苦逼、最有技术含量的活儿开始了。

编译通过后，从kernel/liteos_a/arch/arm/arm/src/startup/reset_vector_mp.S一路跟踪，

反复进行：修改、编译、下载运行测试